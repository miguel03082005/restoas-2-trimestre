function funcionEliminar() {
    var opcion= confirm("Click en aceptar o cancelar")
}