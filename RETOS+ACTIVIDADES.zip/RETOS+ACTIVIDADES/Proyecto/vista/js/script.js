let number1=1;
let number2=2;
let word="miguel";
let state=true;

console.log("hola soy "+word+" el numero que tengo es "+number);
console.log(`hola soy ${word} el numero que tengo es ${number}`);
alert("hola esto es una alerte");
